const todoObjectList = [];

class Todo_Class {
  constructor(item) {
    this.ulElement = item;
  }

  add() {
    const todoInput = document.querySelector("#myInput").value;
    if (todoInput == "") {
      alert("You did not enter any item!");
    } else {
      if (issue == false || loggedIn == true) {
        const todoObject = {
          id: todoObjectList.length,
          todoText: todoInput,
          isDone: false,
        };

        todoObjectList.unshift(todoObject);
        this.display();
        document.querySelector("#myInput").value = "";
      } else {
        alert("Please log in at first");
      }
    }
  }

  done_undone(x) {
    const selectedTodoIndex = todoObjectList.findIndex((item) => item.id == x);
    console.log(todoObjectList[selectedTodoIndex].isDone);
    todoObjectList[selectedTodoIndex].isDone == false
      ? (todoObjectList[selectedTodoIndex].isDone = true)
      : (todoObjectList[selectedTodoIndex].isDone = false);
    this.display();
  }

  deleteElement(z) {
    const selectedDelIndex = todoObjectList.findIndex((item) => item.id == z);

    todoObjectList.splice(selectedDelIndex, 1);

    this.display();
  }

  display() {
    this.ulElement.innerHTML = "";

    todoObjectList.forEach((object_item) => {
      const liElement = document.createElement("li");
      const delBtn = document.createElement("i");

      liElement.innerText = object_item.todoText;
      liElement.setAttribute("data-id", object_item.id);

      delBtn.setAttribute("data-id", object_item.id);
      delBtn.classList.add("far", "fa-trash-alt");

      liElement.appendChild(delBtn);

      delBtn.addEventListener("click", function (e) {
        const deleteId = e.target.getAttribute("data-id");
        myTodoList.deleteElement(deleteId);
      });

      liElement.addEventListener("click", function (e) {
        const selectedId = e.target.getAttribute("data-id");
        myTodoList.done_undone(selectedId);
      });

      if (object_item.isDone) {
        liElement.classList.add("checked");
      }

      this.ulElement.appendChild(liElement);
    });
  }
}

const listSection = document.querySelector("#myUL");

myTodoList = new Todo_Class(listSection);

document.querySelector(".addBtn").addEventListener("click", function () {
  checkIfLoggedIn();
});

document.querySelector(".addBtn").addEventListener(`submit`, function () {
  checkIfLoggedIn();
});

document.querySelector("#myInput").addEventListener("keydown", function (e) {
  if (e.keyCode == 13) {
    myTodoList.add();
  }
});

//LOGIN

function checkIfLoggedIn() {
  if (loggedIn == true || issue == false) {
    myTodoList.add();
    document.querySelector(".hid-letuserknow").className = "letUserKnow";
  } else {
    alert("Please Log In at first!");
  }
}

var issue;
var loggedIn;
var msg;
const LoginBtn = document.getElementById("login-btn");

LoginBtn.addEventListener("click", (e) => {
  e.preventDefault();
  const login = "http://localhost:3000/login";
  const Username_text = document.getElementById("username").value;
  const Password_text = document.getElementById("password").value;
  fetch(login, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      username: Username_text,
      password: Password_text,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      issue = data.err;
      loggedIn = data.login;
      msg = data.msg;
    })
    .then(() => {
      if (issue == false || loggedIn == true) {
        consoleLogged();
      } else if (issue == true || loggedIn == false) {
        consoleNotLogged();
      }
    })
    .catch((err) => {
      console.log(err);
    });
});

function consoleLogged() {
  document.querySelector(".before-login").innerHTML = msg;
  document.querySelector(".hid-letuserknow").className = "letUserKnow";
  const button = document.getElementById("ToLinkHome");
  button.click();
}

function consoleNotLogged() {
  document.querySelector(".before-login").innerHTML = msg;
}

//Automatisch Testing (3 Anzeige Bereich)

// setTimeout(click1, 5000);
// function click1() {
//   document.getElementById("link1").click();
//   document.getElementById("link2").click();
//   document.getElementById("link3").click();
// }
